const Home = () => {
  return (
    <div className="w-full h-screen flex justify-center bg-[#f3f8c5] pt-20">
      <p className="font-bold text-lg">Go to /dashboard to view the Dashboard</p>
    </div>
  );
};

export default Home;
