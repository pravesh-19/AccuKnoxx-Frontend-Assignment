# Frontend Assignmnet Accuknox

### 1.Create a Json to build this dashboard / widget dynamically. Json should contain categories and each category can contain multiple widgets.
### 2. Users should be able to dynamically add a widget and remove a widget from a section/ category. eg : CSPM Executive dashboard is a category.
### 3. For individual widget, for assignment purposes we can just put random text.
### 4. Once the user clicks on +Add Widget, users should be able to add Widget name, widget text , and it should be added to that category.
### 5. On each widget, we can have a cross icon to remove it from a category or users can go to add category section and uncheck from category list
### 6. Users should be able to search in a list of all the widgets.
